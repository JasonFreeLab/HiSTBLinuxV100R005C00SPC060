#ifndef HWLOC_PORT_FREEBSD_SYS_THR_H
#define HWLOC_PORT_FREEBSD_SYS_THR_H

int thr_self(long *id);

#endif /* HWLOC_PORT_FREEBSD_SYS_THR_H */
