# Security Policy

## Supported Versions

WFB-ng versions being supported with security updates:

| Version | Supported          |
| ------- | ------------------ |
| master  | :white_check_mark: |
| 23.08   | :white_check_mark: |
| < 23.08 | :x:                |

## Reporting a Vulnerability

To report vulnerability please mail to svpcom@p2ptech.org
