---
name: ⛔ Support Question
about: See https://github.com/svpcom/wfb-ng/discussions for questions about using WFB.

---

We use GitHub issues only to discuss WFB bugs and new features. For
questions about using WFB or related components, please use https://github.com/svpcom/wfb-ng/discussions

Thanks!


