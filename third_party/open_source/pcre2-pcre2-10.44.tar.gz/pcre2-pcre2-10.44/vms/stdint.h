#ifndef MY_VMS_STDINT
#define MY_VMS_STDINT
#include <inttypes.h>
#include <limits.h>
#include <stdbool.h>
#define SIZE_MAX UINT_MAX
#define UINT32_MAX  4294967295u
#define UINT16_MAX             (65535)
#endif
